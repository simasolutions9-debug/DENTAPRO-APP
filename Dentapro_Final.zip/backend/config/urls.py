from django.urls import include, path

urlpatterns = [
    path("api/auth/", include("auth.urls")),
    path("api/v1/", include("core.urls")),
    path("api/v1/auth/", include("auth.urls")),
]
